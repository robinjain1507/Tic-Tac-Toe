package com.example.raisa.myapplication;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class Workshop extends AppCompatActivity {
private ImageView img11 , img12 , img13, img21, img22, img23, img31, img32, img33;
private boolean player1=true;
private Button btnReset , btnExit;
private int steps =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workshop);
        img11 = (ImageView)findViewById(R.id.img11);
        img12 = (ImageView)findViewById(R.id.img12);
        img13 = (ImageView)findViewById(R.id.img13);
        img21 = (ImageView)findViewById(R.id.img21);
        img22 = (ImageView)findViewById(R.id.img22);
        img23 = (ImageView)findViewById(R.id.img23);
        img31 = (ImageView)findViewById(R.id.img31);
        img32 = (ImageView)findViewById(R.id.img32);
        img33 = (ImageView)findViewById(R.id.img33);
        btnExit =(Button) findViewById(R.id.exit);
        btnReset = (Button) findViewById(R.id.reset);
        settingTags();
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reset();
                resumeClicks();
                settingTags();
                steps =0;
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.exit(0);
            }
        });
        img11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img11.setImageResource(R.drawable.x);
                    img11.setTag(1);
                    player1 = false;
                }
                else {
                    img11.setImageResource(R.drawable.o);
                    img11.setTag(0);
                    player1=true;
                }
                img11.setClickable(false);
                checkWinner();
            }
        });

        img12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img12.setImageResource(R.drawable.x);
                    img12.setTag(1);
                    player1 = false;
                }
                else {
                    img12.setImageResource(R.drawable.o);
                    img12.setTag(0);
                    player1=true;
                }
                checkWinner();
                img12.setClickable(false);
            }
        });
        img13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img13.setImageResource(R.drawable.x);
                    img13.setTag(1);
                    player1 = false;
                }
                else {
                    img13.setImageResource(R.drawable.o);
                    img13.setTag(0);
                    player1=true;
                }
                img13.setClickable(false);
                checkWinner();

            }
        });
        img21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img21.setImageResource(R.drawable.x);
                    img21.setTag(1);
                    player1 = false;
                }
                else {
                    img21.setImageResource(R.drawable.o);
                    player1=true;
                    img21.setTag(0);
                }
                img21.setClickable(false);
                checkWinner();
            }
        });
        img22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img22.setImageResource(R.drawable.x);
                    img22.setTag(1);
                    player1 = false;
                }
                else {
                    img22.setImageResource(R.drawable.o);
                    player1=true;
                    img22.setTag(0);
                }
                img22.setClickable(false);
                checkWinner();
            }
        });
        img23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img23.setImageResource(R.drawable.x);
                    img23.setTag(1);
                    player1 = false;
                }
                else {
                    img23.setImageResource(R.drawable.o);
                    player1=true;
                    img23.setTag(0);
                }
                checkWinner();
                img23.setClickable(false);
            }
        });
        img31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img31.setImageResource(R.drawable.x);
                    img31.setTag(1);
                    player1 = false;
                }
                else {
                    img31.setImageResource(R.drawable.o);
                    player1=true;
                    img31.setTag(0);
                }
                checkWinner();
                img31.setClickable(false);
            }
        });
        img32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img32.setImageResource(R.drawable.x);
                    img32.setTag(1);
                    player1 = false;
                }
                else {
                    img32.setImageResource(R.drawable.o);
                    player1=true;
                    img32.setTag(0);
                }
                checkWinner();
                img32.setClickable(false);
            }
        });
        img33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                steps++;
                if(player1){
                    img33.setImageResource(R.drawable.x);
                    img33.setTag(1);
                    player1 = false;
                }
                else {
                    img33.setImageResource(R.drawable.o);
                    player1=true;
                    img33.setTag(0);
                }
                img33.setClickable(false);
                checkWinner();
            }
        });

    }
    public void checkWinner(){
        if((Integer)img11.getTag()==(Integer)img12.getTag() &&(Integer)img11.getTag()==(Integer)img13.getTag() ){
            dialogBox((Integer)img11.getTag());
        }
        else if((Integer)img21.getTag()==(Integer)img22.getTag() &&(Integer)img21.getTag()==(Integer)img23.getTag() ){
            dialogBox((Integer)img21.getTag());
        }
        else if((Integer)img31.getTag()==(Integer)img32.getTag() &&(Integer)img31.getTag()==(Integer)img33.getTag() ){
            dialogBox((Integer)img31.getTag());
        }
        else if((Integer)img11.getTag()==(Integer)img21.getTag() &&(Integer)img11.getTag()==(Integer)img31.getTag() ){
            dialogBox((Integer)img11.getTag());
        }
        else if((Integer)img12.getTag()==(Integer)img22.getTag() &&(Integer)img12.getTag()==(Integer)img32.getTag() ){
            dialogBox((Integer)img12.getTag());
        }
        else if((Integer)img13.getTag()==(Integer)img23.getTag() &&(Integer)img13.getTag()==(Integer)img33.getTag() ){
            dialogBox((Integer)img13.getTag());
        }
        else if((Integer)img11.getTag()==(Integer)img22.getTag() &&(Integer)img11.getTag()==(Integer)img33.getTag() ){
            dialogBox((Integer)img11.getTag());
        }
        else if((Integer)img13.getTag()==(Integer)img22.getTag() &&(Integer)img13.getTag()==(Integer)img31.getTag() ){
            dialogBox((Integer)img13.getTag());
        }
        else{
            if(steps==9){
             dialogBox(4);
            }
        }

    }
    public  void dialogBox(int x){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Congratulations !!");
        alert.setNegativeButton("exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                System.exit(0);
            }
        });
        alert.setPositiveButton("Return to game", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                reset();
                resumeClicks();
                settingTags();
                steps =0;
            }
        });
        if(x == 1){
        alert.setMessage("The winner is X");
        alert.show();
        }
        else if(x==0){
            alert.setMessage("The winner is O");
            alert.show();
        }
        else if(x==4){
            alert.setMessage("Draw!!");
            alert.setTitle("OOPS");
            alert.show();
           // Toast.makeText(this, "hello", Toast.LENGTH_SHORT).show();
        }


    }
    public  void reset(){
        img11.setImageResource(R.drawable.blank);
        img12.setImageResource(R.drawable.blank);
        img13.setImageResource(R.drawable.blank);
        img21.setImageResource(R.drawable.blank);
        img22.setImageResource(R.drawable.blank);
        img23.setImageResource(R.drawable.blank);
        img31.setImageResource(R.drawable.blank);
        img32.setImageResource(R.drawable.blank);
        img33.setImageResource(R.drawable.blank);

    }
    public void settingTags() {
        img11.setTag(2);
        img12.setTag(2);
        img13.setTag(2);
        img21.setTag(2);
        img22.setTag(2);
        img23.setTag(2);
        img31.setTag(2);
        img32.setTag(2);
        img33.setTag(2);
    }
    public void resumeClicks(){
        img11.setClickable(true);
        img12.setClickable(true);
        img13.setClickable(true);
        img21.setClickable(true);
        img22.setClickable(true);
        img23.setClickable(true);
        img31.setClickable(true);
        img32.setClickable(true);
        img33.setClickable(true);
    }
}
